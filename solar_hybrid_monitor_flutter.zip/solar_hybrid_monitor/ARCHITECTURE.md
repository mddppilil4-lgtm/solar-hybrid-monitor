# Architecture decisions

1. The hardware is SPI-10K-H3P + SOLARMAN LSW-5.
2. The first production path is SOLARMAN OpenAPI, not assumed TCP:502/8899.
3. LSW-5 is a BLE 5.0 + RS485 logger and communicates with SOLARMAN; the app should not assume that BLE exposes Modbus directly.
4. Monitoring uses POST /device/v1.0/currentData and consumes its dataList dynamically.
5. Control is intentionally disabled until SOLARMAN account permissions and the SPI-H3P write protocol are verified.
6. The app supports demo mode so the UI can be evaluated immediately.
