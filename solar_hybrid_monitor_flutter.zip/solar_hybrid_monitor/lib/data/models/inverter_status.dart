class DataPoint {
  final String key;
  final String value;
  final String unit;
  final String name;

  const DataPoint({
    required this.key,
    required this.value,
    required this.unit,
    required this.name,
  });

  factory DataPoint.fromJson(Map<String, dynamic> json) {
    return DataPoint(
      key: '${json['key'] ?? ''}',
      value: '${json['value'] ?? ''}',
      unit: '${json['unit'] ?? ''}',
      name: '${json['name'] ?? ''}',
    );
  }

  double? get number => double.tryParse(value.replaceAll(',', ''));
}

class InverterStatus {
  final String deviceSn;
  final int deviceState;
  final DateTime? collectionTime;
  final List<DataPoint> points;

  const InverterStatus({
    required this.deviceSn,
    required this.deviceState,
    required this.collectionTime,
    required this.points,
  });

  factory InverterStatus.fromJson(Map<String, dynamic> json) {
    final raw = (json['dataList'] as List?) ?? const [];
    final timestamp = json['collectionTime'];
    return InverterStatus(
      deviceSn: '${json['deviceSn'] ?? ''}',
      deviceState: (json['deviceState'] as num?)?.toInt() ?? 3,
      collectionTime: timestamp is num
          ? DateTime.fromMillisecondsSinceEpoch(timestamp.toInt() * 1000)
          : null,
      points: raw
          .whereType<Map>()
          .map((e) => DataPoint.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }

  DataPoint? findByNames(List<String> names) {
    final normalized = names.map(_norm).toSet();
    for (final p in points) {
      if (normalized.contains(_norm(p.name)) ||
          normalized.contains(_norm(p.key))) {
        return p;
      }
    }
    return null;
  }

  double? numberFor(List<String> names) => findByNames(names)?.number;

  static String _norm(String s) => s
      .toLowerCase()
      .replaceAll(' ', '')
      .replaceAll('_', '')
      .replaceAll('-', '')
      .replaceAll('/', '');
}
