import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/inverter_status.dart';

class SolarmanService {
  Future<InverterStatus> getCurrentData({
    required String baseUrl,
    required String accessToken,
    required String deviceSn,
  }) async {
    final uri = Uri.parse(
      '${baseUrl.replaceFirst(RegExp(r'/$'), '')}/device/v1.0/currentData?language=en',
    );

    final response = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'bearer $accessToken',
          },
          body: jsonEncode({'deviceSn': deviceSn}),
        )
        .timeout(const Duration(seconds: 12));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('HTTP ${response.statusCode}: ${response.body}');
    }

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    if (json['success'] == false) {
      throw Exception(json['msg'] ?? 'SOLARMAN API error');
    }
    return InverterStatus.fromJson(json);
  }
}
