import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../logic/inverter_provider.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<InverterProvider>(
      builder: (context, vm, _) {
        final s = vm.status;
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('مراقب الطاقة الشمسية'),
              actions: [
                IconButton(
                  tooltip: 'تحديث',
                  onPressed: vm.loading ? null : vm.refresh,
                  icon: const Icon(Icons.refresh),
                ),
                IconButton(
                  tooltip: 'الإعدادات',
                  onPressed: () => _showSettings(context, vm),
                  icon: const Icon(Icons.settings_outlined),
                ),
              ],
            ),
            body: RefreshIndicator(
              onRefresh: vm.refresh,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _connectionCard(vm),
                  const SizedBox(height: 12),
                  if (vm.error != null)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline),
                            const SizedBox(width: 10),
                            Expanded(child: Text(vm.error!)),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  _energyFlow(vm),
                  const SizedBox(height: 12),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 1.45,
                    children: [
                      _statCard('☀️ الألواح', vm.textValue(['PV Total Power', 'Grid Total Power', 'PG_Pt1'])),
                      _statCard('🔋 البطارية', vm.textValue(['Battery SOC', 'SOC'])),
                      _statCard('🏠 الحمل', vm.textValue(['Load Power', 'Load Total Power'])),
                      _statCard('🌡️ الحرارة', vm.textValue(['Inverter Temperature', 'Temperature'])),
                      _statCard('⚡ الجهد', vm.textValue(['PV Voltage', 'Voltage'])),
                      _statCard('📊 طاقة اليوم', vm.textValue(['Today Energy', 'Daily Energy'])),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('تفاصيل الجهاز', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          Text('الإنفرتر: SPI-10K-H3P'),
                          Text('Logger: LSW-5'),
                          Text('SN: ${s?.deviceSn ?? vm.deviceSn}'),
                          Text('آخر تحديث: ${s?.collectionTime ?? '--'}'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _connectionCard(InverterProvider vm) {
    final online = vm.status?.deviceState == 1;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              child: Icon(online ? Icons.cloud_done : Icons.cloud_off),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(online ? 'متصل' : 'غير متصل',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  Text(vm.demoMode ? 'وضع تجريبي' : 'SOLARMAN Cloud'),
                ],
              ),
            ),
            if (vm.loading)
              const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
          ],
        ),
      ),
    );
  }

  Widget _energyFlow(InverterProvider vm) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('تدفق الطاقة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _flowNode('☀️', 'PV', vm.textValue(['PV Total Power', 'PG_Pt1'])),
                const Icon(Icons.arrow_back),
                _flowNode('⚡', 'Inverter', '10 kW'),
                const Icon(Icons.arrow_back),
                _flowNode('🏠', 'Load', vm.textValue(['Load Power', 'Load Total Power'])),
              ],
            ),
            const SizedBox(height: 14),
            _flowNode('🔋', 'Battery', vm.textValue(['Battery SOC', 'SOC'])),
          ],
        ),
      ),
    );
  }

  Widget _flowNode(String icon, String label, String value) {
    return Column(
      children: [
        Text(icon, style: const TextStyle(fontSize: 28)),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        Text(value),
      ],
    );
  }

  Widget _statCard(String title, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Future<void> _showSettings(BuildContext context, InverterProvider vm) async {
    final base = TextEditingController(text: vm.baseUrl);
    final token = TextEditingController(text: vm.accessToken);
    final sn = TextEditingController(text: vm.deviceSn);
    bool demo = vm.demoMode;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setState) => Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(context).viewInsets.bottom + 16),
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('إعدادات الاتصال', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  TextField(controller: base, decoration: const InputDecoration(labelText: 'SOLARMAN Base URL')),
                  TextField(controller: sn, decoration: const InputDecoration(labelText: 'Logger / Device SN')),
                  TextField(
                    controller: token,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Access Token'),
                  ),
                  SwitchListTile(
                    value: demo,
                    onChanged: (v) => setState(() => demo = v),
                    title: const Text('الوضع التجريبي'),
                    subtitle: const Text('اختبار الواجهة دون الاتصال بالسحابة'),
                  ),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: () async {
                      await vm.saveSettings(
                        newBaseUrl: base.text,
                        newToken: token.text,
                        newDeviceSn: sn.text,
                        newDemoMode: demo,
                      );
                      if (context.mounted) Navigator.pop(context);
                    },
                    icon: const Icon(Icons.save),
                    label: const Text('حفظ'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    base.dispose();
    token.dispose();
    sn.dispose();
  }
}
