import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/models/inverter_status.dart';
import '../data/services/solarman_service.dart';

class InverterProvider extends ChangeNotifier {
  final SolarmanService service;
  InverterProvider(this.service);

  String baseUrl = 'https://globalapi.solarmanpv.com';
  String accessToken = '';
  String deviceSn = '3589558525';
  bool demoMode = true;
  bool loading = false;
  String? error;
  InverterStatus? status;
  Timer? _timer;

  Future<void> loadSettings() async {
    final p = await SharedPreferences.getInstance();
    baseUrl = p.getString('baseUrl') ?? baseUrl;
    accessToken = p.getString('accessToken') ?? '';
    deviceSn = p.getString('deviceSn') ?? deviceSn;
    demoMode = p.getBool('demoMode') ?? true;
    notifyListeners();
    if (demoMode) {
      _startPolling();
    }
  }

  Future<void> saveSettings({
    required String newBaseUrl,
    required String newToken,
    required String newDeviceSn,
    required bool newDemoMode,
  }) async {
    final p = await SharedPreferences.getInstance();
    baseUrl = newBaseUrl.trim();
    accessToken = newToken.trim();
    deviceSn = newDeviceSn.trim();
    demoMode = newDemoMode;
    await p.setString('baseUrl', baseUrl);
    await p.setString('accessToken', accessToken);
    await p.setString('deviceSn', deviceSn);
    await p.setBool('demoMode', demoMode);
    notifyListeners();
    _timer?.cancel();
    if (demoMode) {
      _startPolling();
    }
  }

  void _startPolling() {
    _timer?.cancel();
    refresh();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => refresh());
  }

  Future<void> refresh() async {
    if (loading) return;
    loading = true;
    error = null;
    notifyListeners();

    try {
      if (demoMode) {
        status = _demoStatus();
      } else {
        if (accessToken.isEmpty || deviceSn.isEmpty) {
          throw Exception('أدخل Access Token وSN الجهاز أولًا.');
        }
        status = await service.getCurrentData(
          baseUrl: baseUrl,
          accessToken: accessToken,
          deviceSn: deviceSn,
        );
      }
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  InverterStatus _demoStatus() {
    final t = DateTime.now().millisecondsSinceEpoch / 60000.0;
    final pv = 5600 + 1200 * sin(t);
    final load = 1500 + 500 * sin(t * 1.3);
    final battery = 76 + 3 * sin(t / 3);
    return InverterStatus(
      deviceSn: deviceSn,
      deviceState: 1,
      collectionTime: DateTime.now(),
      points: [
        DataPoint(key: 'PG_Pt1', value: pv.toStringAsFixed(0), unit: 'W', name: 'PV Total Power'),
        DataPoint(key: 'BatterySOC', value: battery.toStringAsFixed(0), unit: '%', name: 'Battery SOC'),
        DataPoint(key: 'GridPower', value: '0', unit: 'W', name: 'Grid Power'),
        DataPoint(key: 'LoadPower', value: load.toStringAsFixed(0), unit: 'W', name: 'Load Power'),
        DataPoint(key: 'PVVoltage', value: '520', unit: 'V', name: 'PV Voltage'),
        DataPoint(key: 'BatteryVoltage', value: '52.4', unit: 'V', name: 'Battery Voltage'),
        DataPoint(key: 'Temperature', value: '41', unit: '°C', name: 'Inverter Temperature'),
        DataPoint(key: 'Frequency', value: '50', unit: 'Hz', name: 'Frequency'),
        DataPoint(key: 'TodayEnergy', value: '18.6', unit: 'kWh', name: 'Today Energy'),
      ],
    );
  }

  double? value(List<String> names) => status?.numberFor(names);

  String textValue(List<String> names, {String fallback = '--'}) {
    final p = status?.findByNames(names);
    if (p == null || p.value.isEmpty) return fallback;
    return '${p.value}${p.unit.isEmpty ? '' : ' ${p.unit}'}';
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
