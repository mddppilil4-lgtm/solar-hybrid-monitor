import 'package:flutter_test/flutter_test.dart';
import 'package:solar_hybrid_monitor/main.dart';

void main() {
  testWidgets('dashboard loads', (tester) async {
    await tester.pumpWidget(const SolarApp());
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('مراقب الطاقة الشمسية'), findsOneWidget);
  });
}
